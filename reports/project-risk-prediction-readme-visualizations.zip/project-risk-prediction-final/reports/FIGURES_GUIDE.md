# Visualization guide

All figures in `figures/` are derived from the supplied notebook's saved output cells, except the model comparison and XGBoost generalization charts, which were recreated from the exact metric values printed in those outputs.

## Figure inventory

- `model_performance_comparison.png` — compares accuracy, macro precision, macro recall, macro F1 and weighted F1 for all three models.
- `xgboost_generalization_gap.png` — compares XGBoost training accuracy, test accuracy and the reported mean cross-validation score.
- `confusion_matrix_logistic_regression.png` — notebook confusion matrix for Logistic Regression.
- `confusion_matrix_random_forest.png` — notebook confusion matrix for Random Forest.
- `confusion_matrix_xgboost.png` — notebook confusion matrix for XGBoost.
- `xgboost_feature_importance_top10.png` — notebook top-ten XGBoost feature-importance chart.
- `xgboost_feature_importance_all.png` — notebook full feature-importance chart.
- `shap_summary_beeswarm.png` — notebook SHAP summary beeswarm plot.
- `shap_summary_bar.png` — notebook SHAP global bar plot.

The target labels in confusion matrices are encoded 0–3. Do not relabel them as named risk categories until the original `Risk_Level` label mapping is confirmed. Feature-importance and SHAP plots describe the current fitted XGBoost model and must be re-generated after leakage-free model validation.
