# Project Risk Prediction & Analytics

**Machine Learning for Project Risk Classification and Management Decision Support**

[![Python](https://img.shields.io/badge/Python-3.x-blue.svg)](https://www.python.org/)
[![Models](https://img.shields.io/badge/Models-Logistic%20Regression%20%7C%20Random%20Forest%20%7C%20XGBoost-informational.svg)]()
[![Status](https://img.shields.io/badge/Status-Research%20Prototype-orange.svg)]()

## 1. Project overview

This project investigates how machine learning can be used to classify project risk levels using project-related characteristics. The notebook analyses 4,000 project records and 51 original columns, then compares Logistic Regression, Random Forest and XGBoost classifiers.

The analysis explores project attributes such as complexity, team experience, stakeholder availability, organizational process maturity, risk-management maturity and technology familiarity. It also uses feature-importance analysis and SHAP to examine how the XGBoost model uses input features.

The intended application is to explore how predictive analytics might complement project monitoring, risk assessment and management decision-making. This is a **research and portfolio prototype**, not a validated operational risk-scoring system.

## 2. Business problem and objective

Project managers and portfolio oversight teams need timely information to identify projects that may require closer monitoring or management attention. This project explores whether patterns in project characteristics can help classify recorded project risk levels.

**Objectives**
- Explore the structure and completeness of the project dataset.
- Prepare numerical and categorical predictors for machine learning.
- Compare three classification algorithms.
- Evaluate predictions using accuracy, precision, recall, F1-score and confusion matrices.
- Examine XGBoost feature importance and SHAP explanations.
- Identify improvements needed before reliable deployment.

## 3. Dataset

| Item | Notebook information |
|---|---|
| Records | 4,000 |
| Original columns | 51 |
| Identifier removed | `Project_ID` |
| Target | `Risk_Level` |
| Prediction type | Multiclass classification |
| Encoded target classes | 0, 1, 2 and 3 |

The notebook reads a local CSV file named `Project_risk_raw_dataset.csv`. That CSV was not included with the notebook supplied for this review. Therefore, the dataset source, licence, data dictionary, original risk-category names and class proportions have not been independently verified.

Do not publish confidential, personal, proprietary or restricted project information. Document the dataset source and redistribution permission before making the raw data public.

## 4. Methodology

The notebook describes its approach as following the IBM Data Science Methodology and implements the following analytical workflow:

1. Load the project-risk dataset.
2. Inspect dimensions, data types and missing values.
3. Visualize missingness using Missingno.
4. Remove the `Project_ID` identifier.
5. Impute categorical missing values with the mode.
6. Impute numerical missing values with the median.
7. Encode the `Risk_Level` target using `LabelEncoder`.
8. Apply one-hot encoding to categorical predictors.
9. Split the data into training and test subsets (80% / 20%), stratified by target, with `random_state=42`.
10. Standardize features for Logistic Regression.
11. Train Logistic Regression, Random Forest and XGBoost classifiers.
12. Compare test-set classification reports and confusion matrices.
13. Inspect XGBoost feature importance.
14. Use SHAP summary plots to explore feature contributions.
15. Save the fitted XGBoost estimator as `project_risk_model.pkl`.
16. Calculate a five-fold cross-validation score for XGBoost.

## 5. Model performance

The table below transcribes the scores displayed in the notebook's test-set classification reports. Values are rounded as displayed.

| Model | Accuracy | Macro precision | Macro recall | Macro F1 | Weighted F1 |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | **0.7325** | **0.75** | **0.73** | **0.74** | **0.73** |
| Random Forest | 0.5025 | 0.56 | 0.47 | 0.48 | 0.48 |
| XGBoost | 0.5725 | 0.60 | 0.56 | 0.57 | 0.57 |

### Test-set comparison

![Model performance comparison](reports/figures/model_performance_comparison.png)

**Current result:** Logistic Regression has the highest recorded test accuracy (73.25%) and macro F1 (0.74) among the three models. It is therefore the strongest model in the notebook's current test-set comparison. These results are preliminary because preprocessing is performed before the split, as explained in the limitations section.

### XGBoost generalization diagnostic

The notebook records:
- Training accuracy: **1.0000**
- Test accuracy: **0.5725**
- Mean five-fold cross-validation score: **0.57125**

![XGBoost generalization gap](reports/figures/xgboost_generalization_gap.png)

The large training-to-test gap is a strong indication that the current XGBoost model overfits the training data. In addition, the cross-validation score is calculated after preprocessing has already been performed on the full dataset, so it is not a leakage-free validation estimate.

## 6. Confusion matrices

The following confusion matrices are extracted from the notebook's recorded outputs. The target classes are shown as encoded values (0–3); the original category names need to be confirmed from the source dataset and label encoder.

### Logistic Regression

![Logistic Regression confusion matrix](reports/figures/confusion_matrix_logistic_regression.png)

### Random Forest

![Random Forest confusion matrix](reports/figures/confusion_matrix_random_forest.png)

### XGBoost

![XGBoost confusion matrix](reports/figures/confusion_matrix_xgboost.png)

## 7. Feature importance and model explainability

The notebook calculates XGBoost feature importance and SHAP values. Its displayed top-ten XGBoost feature-importance table contains:

| Rank | Feature | XGBoost importance |
|---:|---|---:|
| 1 | `Org_Process_Maturity_Optimizing` | 0.032351 |
| 2 | `Technology_Familiarity_New` | 0.024585 |
| 3 | `Team_Experience_Level_Junior` | 0.024073 |
| 4 | `Risk_Management_Maturity_Basic` | 0.022783 |
| 5 | `Complexity_Score` | 0.020826 |
| 6 | `Key_Stakeholder_Availability_Poor` | 0.020522 |
| 7 | `Project_Manager_Experience_Junior PM` | 0.020148 |
| 8 | `Risk_Management_Maturity_Formal` | 0.019384 |
| 9 | `Team_Experience_Level_Mixed` | 0.018568 |
| 10 | `Org_Process_Maturity_Managed` | 0.017452 |

### Top 10 XGBoost feature importance

![Top 10 feature importance](reports/figures/xgboost_feature_importance_top10.png)

### SHAP summary (beeswarm)

![SHAP summary beeswarm](reports/figures/shap_summary_beeswarm.png)

### SHAP global importance

![SHAP summary bar](reports/figures/shap_summary_bar.png)

**Interpretation caution:** These are explanations of the current fitted XGBoost model, not proof that the listed features cause project risk. Because the model shows substantial overfitting and the preprocessing workflow needs correction, feature rankings and SHAP interpretations should be regenerated after the model is revalidated.

## 8. Potential management applications

If future validation supports adequate predictive performance, this type of analysis could be explored to:
- Support project risk screening and monitoring discussions.
- Identify projects that may merit further assessment.
- Help structure review of complexity, team experience, stakeholder availability and process maturity.
- Support portfolio-level analytical reporting.
- Complement established risk registers, project controls and professional judgement.

Model outputs should not be used as the sole basis for project escalation, resource allocation, funding or other consequential decisions.

## 9. Technology stack

- Python
- Pandas and NumPy
- Matplotlib and Seaborn
- scikit-learn
- XGBoost
- SHAP
- Missingno
- Joblib
- Jupyter Notebook / Google Colab

## 10. Repository contents

```text
project-risk-prediction/
├── README.md
├── requirements.txt
├── .gitignore
├── Projects_Risk_Prediction.ipynb
└── reports/
    └── figures/
        ├── model_performance_comparison.png
        ├── xgboost_generalization_gap.png
        ├── confusion_matrix_logistic_regression.png
        ├── confusion_matrix_random_forest.png
        ├── confusion_matrix_xgboost.png
        ├── xgboost_feature_importance_top10.png
        ├── xgboost_feature_importance_all.png
        ├── shap_summary_beeswarm.png
        └── shap_summary_bar.png
```

## 11. How to run the notebook

### Clone the repository

```bash
git clone https://github.com/NematullahAmiri/project-risk-prediction.git
cd project-risk-prediction
```

### Create a virtual environment (Windows)

```bash
python -m venv .venv
.venv\Scripts\activate
```

### Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### Add the dataset

Place the authorised dataset file in the repository root with this exact filename:

```text
Project_risk_raw_dataset.csv
```

The notebook contains a Google Colab upload cell. If running locally, replace that cell with:

```python
import pandas as pd
df = pd.read_csv("Project_risk_raw_dataset.csv")
```

### Launch Jupyter

```bash
jupyter notebook
```

Open `Projects_Risk_Prediction.ipynb` and run the cells in order.

## 12. Limitations and recommended improvements

The current notebook is an exploratory modelling exercise. Before describing the model as validated or deploying it, address the following:

1. **Preprocessing leakage:** The notebook imputes missing values and applies one-hot encoding before the train-test split. Fit imputers and encoders only on training data, using a `ColumnTransformer` and `Pipeline`.
2. **Cross-validation leakage:** The reported XGBoost five-fold score is computed on already-preprocessed data. Repeat cross-validation using a full preprocessing-and-model pipeline inside each fold.
3. **XGBoost overfitting:** The model has 100% training accuracy and 57.25% test accuracy. Investigate model complexity, regularization, class balance and generalization.
4. **Fair model comparison:** Re-evaluate all three models using the same leakage-free preprocessing and stratified folds.
5. **Target class documentation:** Confirm the original `Risk_Level` values and document their mapping to encoded labels 0–3.
6. **Inference artifact:** The notebook saves the XGBoost estimator only. Save the complete fitted preprocessing-and-model pipeline and target-label mapping for reproducible predictions.
7. **Explainability:** Recalculate feature importance and SHAP values after selecting a model through corrected validation.
8. **Data documentation:** Confirm source, licence, data dictionary, class distribution and whether each predictor would be available at the intended prediction time.

## 13. Author

**Nematullah Amiri**  
PMP® | Data Science | Business Intelligence | Project Analytics

- GitHub: [NematullahAmiri](https://github.com/NematullahAmiri)
- Portfolio: [nematullahamiri.github.io](https://nematullahamiri.github.io/)

---

*This repository documents the supplied notebook and its recorded outputs. Model results and feature explanations are preliminary and should not be interpreted as production-validated project risk predictions.*
